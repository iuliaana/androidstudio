package com.example.intent;

import org.junit.Test;

import static org.junit.Assert.*;

import android.text.TextUtils;
import android.util.Patterns;

import java.util.regex.Pattern;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    public boolean isCorrectLogin(String login){
        return (!TextUtils.isEmpty(login)&& Patterns.EMAIL_ADDRESS.matcher(login).matches());
    }
    public String isCorrectPassword(String password){
        String message="";
        Pattern plenght=Pattern.compile(".{6}");
        Pattern pUp=Pattern.compile("[A-ZА-Я]{1}");
        Pattern pNum=Pattern.compile("\\d{1}");
        Pattern pSynbol=Pattern.compile("[!@#$%^&*()]{1}");
        if(!plenght.matcher(password).find()) {
        message+="пароль должен содержать не менее 6 символов\n";
        }
        if(!pUp.matcher(password).find()) {
            message += "пароль должен содержать хотя бы одну букву верхнего регистра";
        }
        if(!pNum.matcher(password).find()){
            message+="пароль должен содержать спецсимвол\n";
        }
        return message;
    }

    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
    @Test
    public void password_isCorrect(){
      String isCorrect="1@#345qqS#$R";
      assertEquals("", isCorrectPassword(isCorrect));
    }
}